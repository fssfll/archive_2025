################################################################################
# mission_five.py
#
# Description:
# [Describe What your mission does here]
#
# Author(s): [Your Name(s)]
# Date: [YYYY-MM-DD]
# Version: 1.0
#
# Dependencies:
# - robot
# - pybricks.tools
#
################################################################################
from robot import robot
from pybricks.parameters import *
from pybricks.tools import *

def mission_five(r):
    print("Running Mission 5")
    # Jackson's pole vaulter 2.0
    r.ram.run_time(200,1700)
    r.robot.straight(500)
    r.robot.straight(-50)
    r.robot.straight(50)
    r.robot.straight(-50)
    r.robot.straight(50)
    r.robot.straight(-50)
    r.robot.straight(50)
    r.robot.straight(-50)
    r.robot.straight(50)
    r.robot.straight(-50)
    r.robot.straight(50)
    r.robot.straight(-50)
    r.robot.straight(50)
    r.robot.straight(-50)
    r.robot.straight(-800)
################################
# KEEP THIS AT THE END OF THE FILE
# This redirects to running main.
################################
if __name__ == "__main__":
    from main import main
    main()