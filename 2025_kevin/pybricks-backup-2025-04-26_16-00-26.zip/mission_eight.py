################################################################################
# mission_eight.py
#
# Description:
# [Describe What your mission does here]
#
# Author(s): [Your Name(s)]
# Date: [YYYY-MM-DD]
# Version: 1.0
#
# Dependencies:
# - robot
# - pybricks.tools
#
################################################################################
from robot import robot
from pybricks.tools import wait, StopWatch

def mission_eight(r):
    print("Running Mission 8")
    # Your code goes here...
    TIRE_DIAMETER = 63  # mm
    AXLE_TRACK = 86  # distance between the wheels, mm
    STRAIGHT_SPEED = 800  # mm/sec
    STRAIGHT_ACCEL = 300  # mm/sec^2
    TURN_RATE = 300  # deg/sec
    TURN_ACCEL = 200  # deg/sec^2

    r.robot.settings(STRAIGHT_SPEED, STRAIGHT_ACCEL, TURN_RATE, TURN_ACCEL)
    r.robot.straight(1000)

################################
# KEEP THIS AT THE END OF THE FILE
# This redirects to running main.
################################
if __name__ == "__main__":
    from main import main
    main()